"""Tests for URDF parsing, FK, Jacobian, IK and path behaviour.

Run:  python -m pytest -q
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from so101_kin import DEFAULT_URDF, SerialChain, cartesian_path, joint_path, path_metrics, solve_ik  # noqa: E402
from so101_kin.ik import TOOL_AXIS  # noqa: E402

DOWN = np.array([0.0, 0.0, -1.0])
ROLL_ONLY = np.array([0, 0, 0, 0, 1.0])


@pytest.fixture(scope="module")
def chain():
    return SerialChain.from_urdf()


# ---------------------------------------------------------------------------
# URDF
# ---------------------------------------------------------------------------

def test_chain_structure(chain):
    assert chain.joint_names == ["shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll"]
    assert chain.joints[-1].type == "fixed"  # gripper_frame_joint: TCP offset, not actuated


def test_limits_match_urdf_text(chain):
    root = ET.parse(DEFAULT_URDF).getroot()
    for name, lo, hi in zip(chain.joint_names, chain.lower, chain.upper):
        lim = root.find(f"joint[@name='{name}']/limit")
        assert lo == pytest.approx(float(lim.get("lower")))
        assert hi == pytest.approx(float(lim.get("upper")))


# ---------------------------------------------------------------------------
# Forward kinematics: compare against an independent quaternion implementation
# ---------------------------------------------------------------------------

def _qmul(a, b):
    w1, x1, y1, z1 = a
    w2, x2, y2, z2 = b
    return np.array([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    ])


def _qaxis(axis, ang):
    axis = np.asarray(axis, float) / np.linalg.norm(axis)
    return np.concatenate([[np.cos(ang / 2)], np.sin(ang / 2) * axis])


def _qrot(q, v):
    return _qmul(_qmul(q, np.concatenate([[0.0], v])), q * np.array([1, -1, -1, -1]))[1:]


def _fk_quaternion(q_joints):
    """Re-derive FK straight from the URDF text using quaternions (no shared code)."""
    root = ET.parse(DEFAULT_URDF).getroot()
    by_child = {j.find("child").get("link"): j for j in root.findall("joint")}
    chain, link = [], "gripper_frame_link"
    while link != "base_link":
        j = by_child[link]
        chain.append(j)
        link = j.find("parent").get("link")
    chain.reverse()
    rot, pos, k = np.array([1.0, 0, 0, 0]), np.zeros(3), 0
    for j in chain:
        o = j.find("origin")
        xyz = np.array([float(v) for v in o.get("xyz").split()])
        r, p, y = (float(v) for v in o.get("rpy").split())
        q_origin = _qmul(_qmul(_qaxis([0, 0, 1], y), _qaxis([0, 1, 0], p)), _qaxis([1, 0, 0], r))
        pos = pos + _qrot(rot, xyz)
        rot = _qmul(rot, q_origin)
        if j.get("type") == "revolute":
            ax = np.array([float(v) for v in j.find("axis").get("xyz").split()])
            rot = _qmul(rot, _qaxis(ax, q_joints[k]))
            k += 1
    return pos, _qrot(rot, np.array([0.0, 0, 1]))


def test_fk_matches_independent_quaternion_fk(chain):
    rng = np.random.default_rng(1)
    for q in [np.zeros(5), *chain.random_q(rng, 50)]:
        T = chain.fk(q)
        p_ref, z_ref = _fk_quaternion(q)
        np.testing.assert_allclose(T[:3, 3], p_ref, atol=1e-12)
        np.testing.assert_allclose(T[:3, 2], z_ref, atol=1e-12)


def test_tool_axis_points_out_of_gripper(chain):
    """TOOL_AXIS (+Z of gripper_frame_link) should point from the wrist towards the fingertips."""
    for q in chain.random_q(np.random.default_rng(2), 20):
        frames, _ = chain.fk_frames(q)
        wrist, tcp = frames[-2][:3, 3], frames[-1][:3, 3]  # gripper_link origin, TCP
        d = (tcp - wrist) / np.linalg.norm(tcp - wrist)
        assert d @ (frames[-1][:3, :3] @ TOOL_AXIS) > 0.99


# ---------------------------------------------------------------------------
# Jacobian
# ---------------------------------------------------------------------------

def _rot_log(R):
    ang = np.arccos(np.clip((np.trace(R) - 1) / 2, -1, 1))
    if ang < 1e-12:
        return np.zeros(3)
    return ang / (2 * np.sin(ang)) * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])


def test_jacobian_matches_finite_differences(chain):
    h = 1e-6
    for q in chain.random_q(np.random.default_rng(3), 20):
        J = chain.jacobian(q)
        T0 = chain.fk(q)
        for k in range(chain.dof):
            dq = np.zeros(5)
            dq[k] = h
            T1 = chain.fk(q + dq)
            v = (T1[:3, 3] - T0[:3, 3]) / h
            w = _rot_log(T1[:3, :3] @ T0[:3, :3].T) / h
            np.testing.assert_allclose(J[:3, k], v, atol=1e-5)
            np.testing.assert_allclose(J[3:, k], w, atol=1e-5)


# ---------------------------------------------------------------------------
# Inverse kinematics
# ---------------------------------------------------------------------------

def test_ik_position_roundtrip(chain):
    rng = np.random.default_rng(4)
    fails = 0
    for q_true in chain.random_q(rng, 40):
        p = chain.fk(q_true)[:3, 3]
        r = solve_ik(chain, p, seed=int(rng.integers(1e6)))
        if not r.success:
            fails += 1
            continue
        assert chain.within_limits(r.q)
        assert np.linalg.norm(chain.fk(r.q)[:3, 3] - p) < 1e-4
    assert fails == 0


def test_ik_position_and_direction_roundtrip(chain):
    # 5 constraints on 5 joints: solutions are isolated and the local solver can miss
    # some (4% in the 200-pose benchmark in results/report.json, mostly folded poses near
    # joint limits). Require >= 90% here and check every reported success for real.
    rng = np.random.default_rng(5)
    fails = 0
    n = 60
    for q_true in chain.random_q(rng, n):
        T = chain.fk(q_true)
        p, d = T[:3, 3], T[:3, :3] @ TOOL_AXIS
        r = solve_ik(chain, p, d, seed=int(rng.integers(1e6)))
        if not r.success:
            fails += 1
            continue
        T2 = chain.fk(r.q)
        assert np.linalg.norm(T2[:3, 3] - p) < 1e-4
        assert np.degrees(np.arccos(np.clip(T2[:3, :3] @ TOOL_AXIS @ d, -1, 1))) < 0.1
        assert chain.within_limits(r.q)
    assert fails <= 0.1 * n


def test_ik_unreachable_reports_failure_and_stays_in_limits(chain):
    r = solve_ik(chain, np.array([1.0, 0.0, 0.2]), max_restarts=3)
    assert not r.success
    assert r.position_error > 0.3
    assert chain.within_limits(r.q)


def test_posture_keeps_wrist_roll_near_zero(chain):
    r = solve_ik(chain, np.array([0.20, -0.12, 0.05]), DOWN, posture=np.zeros(5), posture_weights=ROLL_ONLY)
    assert r.success
    assert abs(np.degrees(r.q[4])) < 1.0


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _endpoints(chain, a, b):
    kw = dict(posture=np.zeros(5), posture_weights=ROLL_ONLY)
    s = solve_ik(chain, np.array(a), DOWN, **kw)
    g = solve_ik(chain, np.array(b), DOWN, q0=s.q, **kw)
    return s, g, kw


def test_cartesian_path_is_straight_and_joint_path_is_not(chain):
    a, b = (0.20, -0.12, 0.05), (0.20, 0.12, 0.05)
    s, g, kw = _endpoints(chain, a, b)
    assert s.success and g.success
    mj = path_metrics(chain, joint_path(chain, s.q, g.q))
    mc = path_metrics(chain, cartesian_path(chain, s.q, np.array(b), DOWN, **kw))
    assert mc["ik_failures"] == 0
    assert mc["max_tracking_error_mm"] < 0.2
    assert mc["max_deviation_from_line_mm"] < 0.2
    assert mc["joint_jumps"] == 0 and mc["within_limits"]
    assert mj["max_deviation_from_line_mm"] > 20  # the arc swings ~40 mm off the line
    assert mj["within_limits"]


def test_vertical_lift_beyond_wrist_limit_is_reported_not_hidden(chain):
    a, b = (0.22, 0.0, 0.03), (0.22, 0.0, 0.15)
    s, g, kw = _endpoints(chain, a, b)
    assert s.success and not g.success  # tool-down pose above ~8 cm needs wrist_flex > 95 deg
    mc = path_metrics(chain, cartesian_path(chain, s.q, np.array(b), DOWN, **kw))
    assert mc["ik_failures"] > 0
    assert mc["max_tracking_error_mm"] > 10
    assert mc["within_limits"]  # clamping keeps the commanded joints legal even when the task fails


def test_limit_helpers(chain):
    q = chain.upper + 0.1
    assert not chain.within_limits(q)
    assert chain.within_limits(chain.clamp(q))
    assert np.all(chain.limit_margin(q) < 0)
