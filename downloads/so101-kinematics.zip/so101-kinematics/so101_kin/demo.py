"""Full study: joint-space vs Cartesian paths on four tabletop moves + workspace map.

Outputs (in --out):
    report.json               all metrics, IK results and workspace summary
    summary.md                human-readable comparison table
    scenario_<name>.png       3-D paths, arm poses and joint trajectories
    workspace.png             reachable / top-down-capable TCP positions
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .ik import solve_ik
from .model import SerialChain
from .paths import cartesian_path, joint_path, path_metrics
from .workspace import sample_workspace

DOWN = np.array([0.0, 0.0, -1.0])
REST = np.zeros(5)  # posture preference ...
REST_W = np.array([0, 0, 0, 0, 1.0])  # ... applied to wrist roll only (it barely moves the TCP)

# (name, description, start xyz [m], goal xyz [m], expected_feasible)
SCENARIOS = [
    ("lateral", "Sideways transfer over the table, tool pointing down",
     (0.20, -0.12, 0.05), (0.20, 0.12, 0.05), True),
    ("radial", "Reach outward along the arm's own plane, tool pointing down",
     (0.13, 0.00, 0.04), (0.28, 0.00, 0.04), True),
    ("approach", "Vertical pick approach: descend 50 mm onto an object",
     (0.22, 0.06, 0.075), (0.22, 0.06, 0.025), True),
    ("lift_fail", "Lift 120 mm straight up with the tool kept vertical (expected to fail)",
     (0.22, 0.00, 0.03), (0.22, 0.00, 0.15), False),
]


def _round(x, nd=3):
    if isinstance(x, float):
        return round(x, nd)
    if isinstance(x, dict):
        return {k: _round(v, nd) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_round(v, nd) for v in x]
    return x


def run_scenario(chain: SerialChain, name, desc, start, goal, expected, n=101):
    start, goal = np.array(start), np.array(goal)
    ik_s = solve_ik(chain, start, DOWN, posture=REST, posture_weights=REST_W)
    ik_g = solve_ik(chain, goal, DOWN, q0=ik_s.q, posture=REST, posture_weights=REST_W)
    jp = joint_path(chain, ik_s.q, ik_g.q, n)
    cp = cartesian_path(chain, ik_s.q, goal, DOWN, n, posture=REST, posture_weights=REST_W)
    mj, mc = path_metrics(chain, jp), path_metrics(chain, cp)
    return {
        "name": name,
        "description": desc,
        "start_xyz_m": start.tolist(),
        "goal_xyz_m": goal.tolist(),
        "expected_feasible": expected,
        "ik_start": {"success": ik_s.success, "q_deg": np.degrees(ik_s.q).tolist(),
                     "pos_err_mm": ik_s.position_error * 1e3, "dir_err_deg": np.degrees(ik_s.direction_error)},
        "ik_goal": {"success": ik_g.success, "q_deg": np.degrees(ik_g.q).tolist(),
                    "pos_err_mm": ik_g.position_error * 1e3, "dir_err_deg": np.degrees(ik_g.direction_error)},
        "joint": mj,
        "cartesian": mc,
        "_paths": (jp, cp),
    }


def _plot_scenario(chain, res, path):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    jp, cp = res["_paths"]
    fig = plt.figure(figsize=(13, 5.2))
    ax = fig.add_subplot(1, 3, 1, projection="3d")
    for q, ls, lab in ((jp.q[0], "-", "start pose"), (jp.q[-1], "--", "goal pose (joint IK)")):
        sk = chain.skeleton(q)
        ax.plot(sk[:, 0], sk[:, 1], sk[:, 2], "k" + ls, marker="o", ms=3, lw=1.2, alpha=0.6, label=lab)
    ax.plot(*jp.tcp.T, color="tab:orange", lw=2, label="joint-space TCP")
    ax.plot(*cp.tcp.T, color="tab:blue", lw=2, label="Cartesian TCP")
    a, b = np.array(res["start_xyz_m"]), np.array(res["goal_xyz_m"])
    ax.plot(*np.vstack([a, b]).T, "k:", lw=1, label="commanded line")
    bad = ~cp.ik_ok
    if bad.any():
        ax.scatter(*cp.tcp[bad].T, color="red", s=10, label="IK failed")
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]"); ax.set_zlabel("z [m]")
    ax.set_title(res["name"])
    ax.legend(fontsize=7, loc="upper left")
    try:
        ax.set_box_aspect((1, 1, 1))
        lim = np.vstack([jp.tcp, cp.tcp, chain.skeleton(jp.q[0]), chain.skeleton(jp.q[-1])])
        c, r = lim.mean(0), (lim.max(0) - lim.min(0)).max() / 2 + 0.02
        ax.set_xlim(c[0] - r, c[0] + r); ax.set_ylim(c[1] - r, c[1] + r); ax.set_zlim(min(0, c[2] - r), c[2] + r)
    except Exception:
        pass

    s = np.linspace(0, 1, len(jp.q))
    for i, (p, title) in enumerate(((jp, "joint-space: joint angles"), (cp, "Cartesian: joint angles"))):
        ax2 = fig.add_subplot(1, 3, 2 + i)
        for k, nm in enumerate(chain.joint_names):
            ax2.plot(s, np.degrees(p.q[:, k]), label=nm)
            ax2.axhline(np.degrees(chain.upper[k]), color=f"C{k}", ls=":", lw=0.6)
            ax2.axhline(np.degrees(chain.lower[k]), color=f"C{k}", ls=":", lw=0.6)
        ax2.set_xlabel("path parameter s"); ax2.set_ylabel("deg"); ax2.set_title(title, fontsize=10)
        ax2.set_ylim(-180, 180)
        if i == 0:
            ax2.legend(fontsize=7)
    m_j, m_c = res["joint"], res["cartesian"]
    goal_note = "" if res["ik_goal"]["success"] else "  [goal IK FAILED: joint path ends at best-effort pose]"
    fig.suptitle(
        f"{res['description']}{goal_note}\n"
        f"joint-space: max deviation {m_j['max_deviation_from_line_mm']:.1f} mm  |  "
        f"Cartesian: tracking error {m_c['max_tracking_error_mm']:.2f} mm, IK failures {m_c['ik_failures']}/{m_c['samples']}"
        "   (simulation only)",
        fontsize=9,
    )
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def _plot_workspace(ws, path):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    p, down = ws["tcp"], ws["top_down"]
    r = np.linalg.norm(p[:, :2], axis=1)
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.8))
    axs[0].scatter(p[:, 0], p[:, 1], s=0.5, c="0.75", label="reachable TCP")
    axs[0].scatter(p[down, 0], p[down, 1], s=1.5, c="tab:green", label="tool within 15 deg of vertical")
    axs[0].set_aspect("equal"); axs[0].set_title("Top view (x-y)"); axs[0].set_xlabel("x [m]"); axs[0].set_ylabel("y [m]")
    axs[0].legend(fontsize=7, markerscale=6)
    axs[1].scatter(r, p[:, 2], s=0.5, c="0.75")
    axs[1].scatter(r[down], p[down, 2], s=1.5, c="tab:green")
    axs[1].axhline(0, color="k", lw=0.8)
    axs[1].set_aspect("equal"); axs[1].set_title("Side view (radius-z)"); axs[1].set_xlabel("horizontal radius [m]"); axs[1].set_ylabel("z [m]")
    fig.suptitle(f"SO-101 TCP workspace, {ws['summary']['samples']} uniform samples within URDF joint limits (no collision model)", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def _summary_md(report) -> str:
    rows = [
        "| Scenario | Method | TCP path (mm) | Max dev. from line (mm) | Tracking err. (mm) | IK fails | Joint travel (rad) | Max joint step (rad) | Min manip. |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for sc in report["scenarios"]:
        for key in ("joint", "cartesian"):
            m = sc[key]
            rows.append(
                f"| {sc['name']} | {key} | {m['tcp_path_length_mm']:.1f} | {m['max_deviation_from_line_mm']:.2f} | "
                f"{m.get('max_tracking_error_mm', float('nan')):.2f} | {m['ik_failures']} | "
                f"{m['total_joint_travel_rad']:.2f} | {m['max_joint_step_rad']:.3f} | {m['min_manipulability']:.4f} |"
            )
    ws = report["workspace"]
    ik = report["ik_benchmark"]
    ik_lines = [
        f"- {mode}: {v['success']}/{v['poses']} solved ({v['success_rate'] * 100:.1f}%), mean random restarts {v['mean_restarts']:.2f}"
        for mode, v in ik.items()
    ]
    out = [
        "# Results (generated by `python -m so101_kin demo`)",
        "",
        "Simulation only. Geometric paths, no timing, dynamics, payload or collision model.",
        "",
        *rows,
        "",
        "Joint-space rows have no tracking error column because they do not try to follow the line.",
        "",
        "## IK round-trip benchmark",
        "",
        "Random joint configurations within limits -> FK -> IK from the zero pose. Failures are listed in report.json.",
        "",
        *ik_lines,
        "",
        "## Where can the tool point straight down? (y = 0 plane, IK with 5 restarts)",
        "",
        "Rows: TCP height z. Columns: TCP x. # = tool-vertical pose found, . = not found.",
        "",
        "```",
        "z [mm] \\ x [mm]: " + " ".join(f"{x * 1000:4.0f}" for x in report["top_down_scan"]["x_m"]),
        *[f"{z * 1000:15.0f}: " + " ".join(f"{'#' if ok else '.':>4}" for ok in row)
          for z, row in zip(report["top_down_scan"]["z_m"], report["top_down_scan"]["feasible"])],
        "```",
        "",
        "## Workspace (Monte Carlo)",
        "",
        f"- Max reach from base origin: {ws['max_reach_mm']:.0f} mm; max horizontal radius: {ws['max_horizontal_radius_mm']:.0f} mm",
        f"- TCP z range: {ws['z_range_mm'][0]:.0f} to {ws['z_range_mm'][1]:.0f} mm",
        f"- Samples with TCP above base plane: {ws['fraction_above_base_plane'] * 100:.1f}%",
        f"- Samples with tool within 15 deg of vertical-down (and above base plane): {ws['fraction_top_down_15deg'] * 100:.2f}%",
    ]
    return "\n".join(out) + "\n"


def ik_benchmark(chain: SerialChain, n: int = 200, seed: int = 10) -> dict:
    """Round-trip test: random legal q -> FK -> IK (from the zero pose) -> success rate."""
    from .ik import TOOL_AXIS

    rng = np.random.default_rng(seed)
    out = {}
    for mode in ("position", "position+direction"):
        ok, restarts, failures = 0, [], []
        for i, q in enumerate(chain.random_q(rng, n)):
            T = chain.fk(q)
            d = T[:3, :3] @ TOOL_AXIS if mode != "position" else None
            r = solve_ik(chain, T[:3, 3], d, seed=i)
            ok += r.success
            restarts.append(r.restarts)
            if not r.success:
                failures.append({"q_true_deg": np.degrees(q).tolist(),
                                 "min_limit_margin_rad": float(chain.limit_margin(q).min()),
                                 "pos_err_mm": r.position_error * 1e3,
                                 "dir_err_deg": float(np.degrees(r.direction_error))})
        out[mode] = {"poses": n, "success": ok, "success_rate": ok / n,
                     "mean_restarts": float(np.mean(restarts)), "failures": failures}
    return out


def top_down_scan(chain: SerialChain, zs=None, rs=None) -> dict:
    """Grid of TCP targets in the x-z plane (y = 0): can the tool point straight down there?"""
    zs = np.round(np.arange(0.02, 0.141, 0.02), 3) if zs is None else zs
    rs = np.round(np.arange(0.08, 0.361, 0.02), 3) if rs is None else rs
    grid = []
    for z in zs:
        row = []
        for r in rs:
            res = solve_ik(chain, np.array([r, 0.0, z]), DOWN, max_restarts=5,
                           posture=REST, posture_weights=REST_W)
            row.append(bool(res.success))
        grid.append(row)
    max_z = max((z for z, row in zip(zs, grid) if any(row)), default=None)
    return {"z_m": [float(z) for z in zs], "x_m": [float(r) for r in rs], "feasible": grid,
            "max_feasible_z_m": None if max_z is None else float(max_z)}


def run_demo(chain: SerialChain, out_dir="results", workspace_samples=20000, ik_samples=200) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    scenarios = [run_scenario(chain, *s) for s in SCENARIOS]
    for sc in scenarios:
        _plot_scenario(chain, sc, out / f"scenario_{sc['name']}.png")
    ws = sample_workspace(chain, workspace_samples)
    _plot_workspace(ws, out / "workspace.png")

    report = {
        "note": "Simulation only: URDF kinematics, no collision, dynamics or hardware validation.",
        "urdf": "TheRobotStudio/SO-ARM100 Simulation/SO101/so101_new_calib.urdf @ a758567",
        "joint_names": chain.joint_names,
        "joint_limits_deg": {n: [float(np.degrees(lo)), float(np.degrees(hi))]
                             for n, lo, hi in zip(chain.joint_names, chain.lower, chain.upper)},
        "scenarios": [{k: v for k, v in sc.items() if not k.startswith("_")} for sc in scenarios],
        "workspace": ws["summary"],
        "ik_benchmark": ik_benchmark(chain, ik_samples),
        "top_down_scan": top_down_scan(chain),
    }
    report["summary"] = {
        sc["name"]: {
            "expected_feasible": sc["expected_feasible"],
            "joint_max_dev_mm": round(sc["joint"]["max_deviation_from_line_mm"], 2),
            "cartesian_tracking_err_mm": round(sc["cartesian"]["max_tracking_error_mm"], 3),
            "cartesian_ik_failures": sc["cartesian"]["ik_failures"],
        }
        for sc in scenarios
    }
    report["summary"]["ik_success_rate"] = {k: v["success_rate"] for k, v in report["ik_benchmark"].items()}
    (out / "report.json").write_text(json.dumps(_round(report, 4), indent=2))
    (out / "summary.md").write_text(_summary_md(report), encoding="utf-8")
    return report
