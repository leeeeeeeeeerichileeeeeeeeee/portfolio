"""SO-101 kinematics toolkit: URDF-based FK, Jacobian IK, path comparison, workspace analysis.

Simulation only. Nothing in this package talks to hardware.
"""

from .model import DEFAULT_URDF, SerialChain
from .ik import IKResult, solve_ik
from .paths import PathResult, cartesian_path, joint_path, path_metrics

__all__ = [
    "DEFAULT_URDF",
    "SerialChain",
    "IKResult",
    "solve_ik",
    "PathResult",
    "joint_path",
    "cartesian_path",
    "path_metrics",
]

__version__ = "0.1.0"
