"""Numerical inverse kinematics (damped least squares) for the 5-DOF SO-101 arm.

Why numerical and not closed-form?
  The SO-101 has 5 arm joints, so a full 6-D pose (position + 3 rotations) is in
  general NOT reachable. What *is* well posed is:
    * position only (3 constraints, 2 redundant DOF), or
    * position + tool approach direction (3 + 2 = 5 constraints).
  Damped least squares handles both cases, stays stable near singularities, and
  works directly from the URDF without hand-derived geometry.

Joint limits are enforced by projecting (clamping) after every step and by
restarting from random seeds if a solve gets stuck against a limit.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .model import SerialChain

# Tool axis used for "approach direction" targets. For gripper_frame_link the
# local +Z axis points out of the gripper between the jaws (checked in tests).
TOOL_AXIS = np.array([0.0, 0.0, 1.0])

# Singular values below this fraction of the largest are treated as null space for the
# posture term. Pointing the tool straight down makes shoulder_pan and wrist_roll both
# rotate about vertical axes, so one direction becomes (nearly) redundant; a loose
# threshold lets the posture term use it even when the tool is only ~0.05 deg off vertical.
NULL_RCOND = 1e-3


@dataclass
class IKResult:
    q: np.ndarray
    success: bool
    position_error: float  # metres
    direction_error: float  # radians (0 if no direction target)
    iterations: int
    restarts: int


def tool_direction(chain: SerialChain, q: np.ndarray) -> np.ndarray:
    return chain.fk(q)[:3, :3] @ TOOL_AXIS


def _errors(chain, q, p_target, d_target):
    T = chain.fk(q)
    e_p = p_target - T[:3, 3]
    if d_target is None:
        return e_p, None, T
    d = T[:3, :3] @ TOOL_AXIS
    # Rotation vector (small-angle) that turns d towards d_target.
    e_d = np.cross(d, d_target)
    return e_p, e_d, T


def solve_ik(
    chain: SerialChain,
    p_target: np.ndarray,
    d_target: np.ndarray | None = None,
    q0: np.ndarray | None = None,
    *,
    pos_tol: float = 1e-4,  # 0.1 mm
    dir_tol: float = 1e-3,  # ~0.06 deg
    max_iter: int = 300,
    damping: float = 1e-2,
    dir_weight: float = 0.1,  # metres per radian: trades 1 rad of direction error vs 10 cm
    max_restarts: int = 20,
    seed: int = 0,
    posture: np.ndarray | None = None,
    posture_gain: float = 0.05,
    posture_weights: np.ndarray | None = None,
) -> IKResult:
    """Solve for joint angles that put the TCP at `p_target` (and optionally point
    the tool axis along `d_target`). Returns the best solution found even on failure.

    posture: optional preferred joint configuration. Redundant DOF (e.g. wrist roll,
    which barely moves the TCP) are nudged towards it in the null space of the task,
    so they do not drift without changing the task error. posture_weights selects which
    joints the preference applies to (default: all)."""
    p_target = np.asarray(p_target, dtype=float)
    if d_target is not None:
        d_target = np.asarray(d_target, dtype=float)
        d_target = d_target / np.linalg.norm(d_target)

    def polished(J, T, q) -> bool:
        if d_target is None:
            A = J[:3]
        else:
            d = T[:3, :3] @ TOOL_AXIS
            A = np.vstack([J[:3], (np.eye(3) - np.outer(d, d)) @ J[3:]])
        N = np.eye(chain.dof) - np.linalg.pinv(A, rcond=NULL_RCOND) @ A
        step = chain.clamp(q + N @ (posture_gain * w_post * (np.asarray(posture) - q))) - q
        return float(np.linalg.norm(step)) < 1e-4

    w_post = np.ones(chain.dof) if posture_weights is None else np.asarray(posture_weights, float)
    rng = np.random.default_rng(seed)
    q_init = chain.clamp(np.zeros(chain.dof) if q0 is None else np.asarray(q0, dtype=float))

    best: IKResult | None = None
    total_iter = 0
    for restart in range(max_restarts + 1):
        q = q_init.copy() if restart == 0 else chain.random_q(rng)
        for it in range(max_iter):
            e_p, e_d, T = _errors(chain, q, p_target, d_target)
            pe = float(np.linalg.norm(e_p))
            de = 0.0
            if e_d is not None:
                d = T[:3, :3] @ TOOL_AXIS
                de = float(np.arccos(np.clip(d @ d_target, -1.0, 1.0)))
            converged = pe < pos_tol and de < dir_tol
            J = chain.jacobian(q)
            if converged:
                # Done, unless a posture preference still wants to move the redundant DOF.
                if posture is None or polished(J, T, q):
                    return IKResult(q, True, pe, de, total_iter + it, restart)
            if e_d is None:
                A, b = J[:3], e_p
            else:
                # Only rotation perpendicular to the tool axis changes its direction.
                d = T[:3, :3] @ TOOL_AXIS
                P = np.eye(3) - np.outer(d, d)
                A = np.vstack([J[:3], dir_weight * (P @ J[3:])])
                b = np.concatenate([e_p, dir_weight * e_d])
            # Damped least squares: dq = A^T (A A^T + lambda^2 I)^-1 b
            A_dls = A.T @ np.linalg.inv(A @ A.T + damping**2 * np.eye(A.shape[0]))
            dq = A_dls @ b
            if posture is not None:
                # Exact (SVD) pseudo-inverse for the projector so the posture term does
                # not leak into the task; the damped inverse is only used for the task step.
                N = np.eye(chain.dof) - np.linalg.pinv(A, rcond=NULL_RCOND) @ A
                dq += N @ (posture_gain * w_post * (np.asarray(posture) - q))
            step = np.linalg.norm(dq)
            if step > 0.3:  # cap step size for stability
                dq *= 0.3 / step
            q = chain.clamp(q + dq)
        total_iter += max_iter
        e_p, _, T = _errors(chain, q, p_target, d_target)
        pe = float(np.linalg.norm(e_p))
        de = 0.0
        if d_target is not None:
            d = T[:3, :3] @ TOOL_AXIS
            de = float(np.arccos(np.clip(d @ d_target, -1.0, 1.0)))
        if pe < pos_tol and de < dir_tol:
            return IKResult(q, True, pe, de, total_iter, restart)
        cand = IKResult(q, False, pe, de, total_iter, restart)
        if best is None or (cand.position_error + dir_weight * cand.direction_error) < (
            best.position_error + dir_weight * best.direction_error
        ):
            best = cand
    return best
