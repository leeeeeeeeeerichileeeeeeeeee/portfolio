"""Monte-Carlo reachable workspace of the TCP within the URDF joint limits."""

from __future__ import annotations

import numpy as np

from .ik import TOOL_AXIS
from .model import SerialChain


def sample_workspace(chain: SerialChain, n: int = 20000, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    qs = chain.random_q(rng, n)
    Ts = [chain.fk(q) for q in qs]
    p = np.array([T[:3, 3] for T in Ts])
    d = np.array([T[:3, :3] @ TOOL_AXIS for T in Ts])
    r = np.linalg.norm(p[:, :2], axis=1)
    above = p[:, 2] >= 0.0
    # "Top-down capable": tool axis within 15 deg of straight down, TCP above the base plane.
    down = above & (d[:, 2] <= -np.cos(np.radians(15)))
    return {
        "q": qs,
        "tcp": p,
        "tool_dir": d,
        "above_base_plane": above,
        "top_down": down,
        "summary": {
            "samples": int(n),
            "max_reach_mm": float(np.linalg.norm(p, axis=1).max() * 1e3),
            "max_horizontal_radius_mm": float(r.max() * 1e3),
            "z_range_mm": [float(p[:, 2].min() * 1e3), float(p[:, 2].max() * 1e3)],
            "fraction_above_base_plane": float(above.mean()),
            "fraction_top_down_15deg": float(down.mean()),
            "top_down_radius_range_mm": (
                [float(r[down].min() * 1e3), float(r[down].max() * 1e3)] if down.any() else None
            ),
        },
    }
