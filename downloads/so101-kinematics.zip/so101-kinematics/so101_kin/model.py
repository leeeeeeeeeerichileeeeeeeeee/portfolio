"""URDF parsing and serial-chain kinematics for the SO-101 arm.

Everything here is plain numpy. Units: metres and radians.

The chain is read directly from the official URDF, so the numbers used for
forward kinematics are the same ones a ROS / MuJoCo / Isaac model would use.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

import numpy as np

DEFAULT_URDF = Path(__file__).resolve().parent.parent / "urdf" / "so101_new_calib.urdf"


# ---------------------------------------------------------------------------
# Small rigid-body helpers
# ---------------------------------------------------------------------------

def rot_x(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def rpy_to_matrix(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """URDF convention: fixed-axis X-Y-Z, i.e. R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
    return rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)


def axis_angle_matrix(axis: np.ndarray, angle: float) -> np.ndarray:
    """Rodrigues' formula for a rotation of `angle` about unit vector `axis`."""
    k = np.asarray(axis, dtype=float)
    k = k / np.linalg.norm(k)
    kx = skew(k)
    return np.eye(3) + np.sin(angle) * kx + (1 - np.cos(angle)) * (kx @ kx)


def skew(v: np.ndarray) -> np.ndarray:
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


def homogeneous(R: np.ndarray, p: np.ndarray) -> np.ndarray:
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = p
    return T


# ---------------------------------------------------------------------------
# URDF model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Joint:
    name: str
    type: str  # "revolute" | "fixed" (prismatic/continuous not needed for SO-101)
    parent: str
    child: str
    origin: np.ndarray  # 4x4 parent->joint frame transform at q = 0
    axis: np.ndarray  # unit axis in the joint frame
    lower: float = -np.inf
    upper: float = np.inf

    @property
    def is_active(self) -> bool:
        return self.type in ("revolute", "continuous", "prismatic")


def _floats(text: str | None, default: str) -> np.ndarray:
    return np.array([float(x) for x in (text or default).split()])


def parse_urdf_joints(path: str | Path) -> dict[str, Joint]:
    root = ET.parse(path).getroot()
    joints: dict[str, Joint] = {}
    for j in root.findall("joint"):
        o = j.find("origin")
        xyz = _floats(o.get("xyz") if o is not None else None, "0 0 0")
        rpy = _floats(o.get("rpy") if o is not None else None, "0 0 0")
        a = j.find("axis")
        axis = _floats(a.get("xyz") if a is not None else None, "1 0 0")
        if np.linalg.norm(axis) > 0:
            axis = axis / np.linalg.norm(axis)
        lim = j.find("limit")
        lower = float(lim.get("lower", -np.inf)) if lim is not None else -np.inf
        upper = float(lim.get("upper", np.inf)) if lim is not None else np.inf
        joints[j.get("name")] = Joint(
            name=j.get("name"),
            type=j.get("type"),
            parent=j.find("parent").get("link"),
            child=j.find("child").get("link"),
            origin=homogeneous(rpy_to_matrix(*rpy), xyz),
            axis=axis,
            lower=lower,
            upper=upper,
        )
    return joints


class SerialChain:
    """Serial kinematic chain between two links of a URDF tree."""

    def __init__(self, joints: list[Joint]):
        self.joints = joints
        self.active = [j for j in joints if j.is_active]
        self.joint_names = [j.name for j in self.active]
        self.lower = np.array([j.lower for j in self.active])
        self.upper = np.array([j.upper for j in self.active])

    @property
    def dof(self) -> int:
        return len(self.active)

    @classmethod
    def from_urdf(
        cls,
        path: str | Path = DEFAULT_URDF,
        base: str = "base_link",
        tip: str = "gripper_frame_link",
    ) -> "SerialChain":
        all_joints = parse_urdf_joints(path)
        by_child = {j.child: j for j in all_joints.values()}
        chain: list[Joint] = []
        link = tip
        while link != base:
            if link not in by_child:
                raise ValueError(f"No path from {base!r} to {tip!r} (stuck at {link!r})")
            j = by_child[link]
            chain.append(j)
            link = j.parent
        return cls(list(reversed(chain)))

    # -- limits --------------------------------------------------------------
    def within_limits(self, q: np.ndarray, tol: float = 1e-9) -> bool:
        q = np.asarray(q)
        return bool(np.all(q >= self.lower - tol) and np.all(q <= self.upper + tol))

    def clamp(self, q: np.ndarray) -> np.ndarray:
        return np.clip(q, self.lower, self.upper)

    def limit_margin(self, q: np.ndarray) -> np.ndarray:
        """Distance (rad) from each joint to its nearest limit. Negative = violated."""
        q = np.asarray(q)
        return np.minimum(q - self.lower, self.upper - q)

    def random_q(self, rng: np.random.Generator, n: int | None = None) -> np.ndarray:
        size = (n, self.dof) if n is not None else (self.dof,)
        return rng.uniform(self.lower, self.upper, size=size)

    # -- forward kinematics --------------------------------------------------
    def fk_frames(self, q: np.ndarray) -> tuple[list[np.ndarray], list[np.ndarray]]:
        """Return (link_frames, joint_frames).

        link_frames[i]  : pose of the child link of joint i (after rotation)
        joint_frames[k] : pose of active joint k's frame (before its rotation),
                          used for the geometric Jacobian.
        """
        q = np.asarray(q, dtype=float)
        if q.shape != (self.dof,):
            raise ValueError(f"expected {self.dof} joint values, got shape {q.shape}")
        T = np.eye(4)
        link_frames, joint_frames = [], []
        k = 0
        for j in self.joints:
            T = T @ j.origin
            if j.is_active:
                joint_frames.append(T.copy())
                T = T @ homogeneous(axis_angle_matrix(j.axis, q[k]), np.zeros(3))
                k += 1
            link_frames.append(T.copy())
        return link_frames, joint_frames

    def fk(self, q: np.ndarray) -> np.ndarray:
        """4x4 pose of the tip link (TCP) in the base frame."""
        return self.fk_frames(q)[0][-1]

    def skeleton(self, q: np.ndarray) -> np.ndarray:
        """Base origin followed by every link origin: an (N+1, 3) polyline for plotting."""
        frames, _ = self.fk_frames(q)
        return np.vstack([np.zeros(3)] + [T[:3, 3] for T in frames])

    # -- differential kinematics ---------------------------------------------
    def jacobian(self, q: np.ndarray) -> np.ndarray:
        """6 x dof geometric Jacobian [v; w] of the TCP, expressed in the base frame."""
        frames, jframes = self.fk_frames(q)
        p_tip = frames[-1][:3, 3]
        J = np.zeros((6, self.dof))
        for k, (Tj, j) in enumerate(zip(jframes, self.active)):
            z = Tj[:3, :3] @ j.axis
            p = Tj[:3, 3]
            J[:3, k] = np.cross(z, p_tip - p)
            J[3:, k] = z
        return J

    def manipulability(self, q: np.ndarray) -> float:
        """Yoshikawa translational manipulability sqrt(det(Jv Jv^T)). Near 0 = near singular."""
        Jv = self.jacobian(q)[:3]
        return float(np.sqrt(max(np.linalg.det(Jv @ Jv.T), 0.0)))
