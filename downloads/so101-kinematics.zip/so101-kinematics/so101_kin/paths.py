"""Joint-space vs Cartesian (straight-line) paths and the metrics used to compare them.

joint_path      : interpolate every joint linearly from q_start to q_goal.
                  Cheap, always within limits if both ends are, but the TCP
                  traces a curve in space.
cartesian_path  : move the TCP along a straight line, solving IK at every
                  sample (warm-started from the previous sample, no random
                  restarts, so a jump in the solution is reported, not hidden).

Both are *geometric* paths: no timing, velocity, dynamics or collision model.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .ik import TOOL_AXIS, solve_ik
from .model import SerialChain


@dataclass
class PathResult:
    method: str
    q: np.ndarray  # (N, dof)
    tcp: np.ndarray  # (N, 3)
    tool_dir: np.ndarray  # (N, 3)
    ik_ok: np.ndarray  # (N,) bool, all True for joint_path
    target_tcp: np.ndarray | None = None  # (N, 3) commanded line for cartesian_path
    metrics: dict = field(default_factory=dict)


def _slerp(a: np.ndarray, b: np.ndarray, s: float) -> np.ndarray:
    a = a / np.linalg.norm(a)
    b = b / np.linalg.norm(b)
    omega = np.arccos(np.clip(a @ b, -1.0, 1.0))
    if omega < 1e-9:
        return a
    return (np.sin((1 - s) * omega) * a + np.sin(s * omega) * b) / np.sin(omega)


def _trace(chain: SerialChain, qs: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    Ts = [chain.fk(q) for q in qs]
    return np.array([T[:3, 3] for T in Ts]), np.array([T[:3, :3] @ TOOL_AXIS for T in Ts])


def joint_path(chain: SerialChain, q_start, q_goal, n: int = 101) -> PathResult:
    q_start, q_goal = np.asarray(q_start, float), np.asarray(q_goal, float)
    s = np.linspace(0.0, 1.0, n)[:, None]
    qs = (1 - s) * q_start + s * q_goal
    tcp, dirs = _trace(chain, qs)
    return PathResult("joint", qs, tcp, dirs, np.ones(n, dtype=bool))


def cartesian_path(
    chain: SerialChain,
    q_start,
    p_goal,
    d_goal=None,
    n: int = 101,
    posture=None,
    posture_weights=None,
) -> PathResult:
    """Straight TCP line from FK(q_start) to p_goal.

    If d_goal is given the tool direction is slerped from its start value to d_goal;
    otherwise only position is constrained (the 2 spare DOF are resolved by
    minimum-norm DLS steps from the previous sample).
    """
    q_start = np.asarray(q_start, float)
    T0 = chain.fk(q_start)
    p0, d0 = T0[:3, 3], T0[:3, :3] @ TOOL_AXIS
    p_goal = np.asarray(p_goal, float)

    qs, ok, targets = [q_start.copy()], [True], [p0.copy()]
    q = q_start.copy()
    for s in np.linspace(0.0, 1.0, n)[1:]:
        p = (1 - s) * p0 + s * p_goal
        d = None if d_goal is None else _slerp(d0, np.asarray(d_goal, float), s)
        res = solve_ik(chain, p, d, q0=q, max_restarts=0, posture=posture, posture_weights=posture_weights)
        q = res.q
        qs.append(q.copy())
        ok.append(res.success)
        targets.append(p)
    qs = np.array(qs)
    tcp, dirs = _trace(chain, qs)
    return PathResult("cartesian", qs, tcp, dirs, np.array(ok), target_tcp=np.array(targets))


def _dist_to_segment(points: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ab = b - a
    L2 = ab @ ab
    if L2 < 1e-15:
        return np.linalg.norm(points - a, axis=1)
    t = np.clip((points - a) @ ab / L2, 0.0, 1.0)
    return np.linalg.norm(points - (a + t[:, None] * ab), axis=1)


def path_metrics(chain: SerialChain, path: PathResult, jump_threshold: float = 0.15) -> dict:
    """Numbers that make the joint-vs-Cartesian trade-off explicit.

    jump_threshold: per-sample joint change (rad) flagged as a discontinuity.
    """
    qs, tcp = path.q, path.tcp
    seg = np.linalg.norm(np.diff(tcp, axis=0), axis=1)
    dq = np.abs(np.diff(qs, axis=0))
    margins = np.array([chain.limit_margin(q) for q in qs])
    manip = np.array([chain.manipulability(q) for q in qs])
    # Lowest point of any link origin (incl. TCP) above the base plane z = 0.
    min_z = min(chain.skeleton(q)[1:, 2].min() for q in qs)
    straight = np.linalg.norm(tcp[-1] - tcp[0])

    m = {
        "method": path.method,
        "samples": int(len(qs)),
        "tcp_path_length_mm": float(seg.sum() * 1e3),
        "straight_line_length_mm": float(straight * 1e3),
        "path_length_ratio": float(seg.sum() / straight) if straight > 1e-12 else float("nan"),
        "max_deviation_from_line_mm": float(_dist_to_segment(tcp, tcp[0], tcp[-1]).max() * 1e3),
        "joint_travel_rad": {n: float(v) for n, v in zip(chain.joint_names, dq.sum(axis=0))},
        "total_joint_travel_rad": float(dq.sum()),
        "max_joint_step_rad": float(dq.max()),
        "joint_jumps": int((dq.max(axis=1) > jump_threshold).sum()),
        "min_limit_margin_rad": {n: float(v) for n, v in zip(chain.joint_names, margins.min(axis=0))},
        "within_limits": bool((margins >= -1e-9).all()),
        "min_manipulability": float(manip.min()),
        "ik_failures": int((~path.ik_ok).sum()),
        "min_link_origin_z_mm": float(min_z * 1e3),
    }
    if path.target_tcp is not None:
        m["max_tracking_error_mm"] = float(np.linalg.norm(tcp - path.target_tcp, axis=1).max() * 1e3)
    path.metrics = m
    return m
