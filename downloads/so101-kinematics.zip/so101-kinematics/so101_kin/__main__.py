"""Command-line entry point.

    python -m so101_kin fk 0 -30 20 40 0          # joint angles in degrees
    python -m so101_kin ik 0.22 0.05 0.08 --down  # TCP target in metres
    python -m so101_kin demo --out results         # full study: figures + report.json
"""

from __future__ import annotations

import argparse
import json

import numpy as np

from .ik import solve_ik
from .model import SerialChain


def _fmt(v):
    return "[" + ", ".join(f"{x:+.4f}" for x in v) + "]"


def main(argv=None):
    ap = argparse.ArgumentParser(prog="so101_kin", description="SO-101 kinematics (simulation only)")
    ap.add_argument("--urdf", default=None, help="path to URDF (default: bundled official SO-101)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_fk = sub.add_parser("fk", help="forward kinematics from 5 joint angles (deg)")
    p_fk.add_argument("q", nargs=5, type=float)

    p_ik = sub.add_parser("ik", help="inverse kinematics to a TCP position (m)")
    p_ik.add_argument("xyz", nargs=3, type=float)
    p_ik.add_argument("--down", action="store_true", help="also require the tool to point straight down")

    p_demo = sub.add_parser("demo", help="run the full joint-vs-Cartesian study")
    p_demo.add_argument("--out", default="results")
    p_demo.add_argument("--samples", type=int, default=20000, help="workspace samples")
    p_demo.add_argument("--ik-samples", type=int, default=200, help="IK benchmark poses")

    args = ap.parse_args(argv)
    chain = SerialChain.from_urdf(args.urdf) if args.urdf else SerialChain.from_urdf()

    if args.cmd == "fk":
        q = np.radians(args.q)
        if not chain.within_limits(q):
            print("WARNING: outside URDF joint limits")
        T = chain.fk(q)
        print("TCP position (m):", _fmt(T[:3, 3]))
        print("Tool axis       :", _fmt(T[:3, 2]))
        print("Manipulability  :", f"{chain.manipulability(q):.5f}")
    elif args.cmd == "ik":
        d = np.array([0, 0, -1.0]) if args.down else None
        r = solve_ik(chain, np.array(args.xyz), d)
        print("success         :", r.success)
        print("q (deg)         :", _fmt(np.degrees(r.q)), dict(zip(chain.joint_names, np.round(np.degrees(r.q), 2))))
        print(f"position error  : {r.position_error * 1e3:.3f} mm")
        print(f"direction error : {np.degrees(r.direction_error):.3f} deg")
        print("restarts        :", r.restarts)
    elif args.cmd == "demo":
        from .demo import run_demo

        report = run_demo(chain, args.out, workspace_samples=args.samples, ik_samples=args.ik_samples)
        print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
