# SO-101 Episode 3: reachable workspace

Status: 38-second review movie rendered; actual MP4 decoded and QA passed. Published to Instagram after approval: https://www.instagram.com/un.built______/reel/DfdNdWeAOtz/

## Reproduce
- With Node.js, run `node reproduce.js` in this folder to repeat the deterministic 20,000-sample kinematic checks. The standalone Node entry point was not executed in the current Guard environment; the calculation was run in Aside REPL.
- Open `preview.html` in a Chromium browser supporting WebCodecs. It is self-contained: official URDF/STL geometry, narration clips, renderer and procedural music are embedded. In the console, `await ep3Encode()` produces `ep3VideoBytes`, which can be saved as an MP4 Blob.
- `production_QA.json` records actual MP4 dimensions, duration, sample counts, presented-frame timestamps and decoded AAC levels. `independent_FK_QA.json` cross-checks 100 complete five-axis configurations against independent Three.js world transforms.

## Interpretation
The SVG is an X-Z projection of above-base samples, not an exact boundary or cross-section. Its skeleton uses official joint frames; the movie uses official STL meshes.

`verification.json` records a reachable witness and a target beyond the conservative distance bound. The bound is the sum of translation-vector lengths from base_link to gripper_frame_link. Rotations preserve lengths and the triangle inequality provides this outer bound. It is NOT the exact maximum reach, and says nothing about reachability of arbitrary inside points. No IK convergence claim is used as proof.

No real-hardware, collision, torque, calibration or load validation. Original geometry/URDF: TheRobotStudio/SO-ARM100, Apache-2.0, revision a758567c3978dfeefe282ede0500085a48fe8f78. See source_notes.txt and LICENSE_Apache-2.0.txt.
