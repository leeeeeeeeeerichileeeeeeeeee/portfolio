const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
require('./so101-kinematics.js');
const model=SO101Kinematics.model(fs.readFileSync(path.join(__dirname,'so101_new_calib.urdf'),'utf8'));
const saved=JSON.parse(fs.readFileSync(path.join(__dirname,'verification.json'),'utf8'));
const names=['shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll'];
const chain=[...names,'gripper_frame_joint'];
const R=chain.reduce((s,n)=>s+Math.hypot(...model.map[n].xyz),0);
const halton=(i,b)=>{let f=1,r=0;while(i>0){f/=b;r+=f*(i%b);i=Math.floor(i/b)}return r;};
let maximum=0,above=0;
for(let i=1;i<=20000;i++){
  const q={gripper:.6};
  names.forEach((n,k)=>{const j=model.map[n];q[n]=j.lower+(j.upper-j.lower)*halton(i,[2,3,5,7,11][k]);assert(q[n]>=j.lower&&q[n]<=j.upper);});
  const p=model.fk(q).p;
  maximum=Math.max(maximum,Math.hypot(...p));
  if(p[2]>=0)above++;
  assert(Math.hypot(...p)<=R+1e-12);
}
const witness=model.fk(saved.reachableWitness.q).p;
assert(Math.hypot(...witness.map((v,i)=>v-saved.reachableWitness.tcp[i]))<1e-12);
assert(Math.hypot(...saved.unreachableTarget)>R);
assert(Math.abs(R-saved.baseOriginConservativeDistanceBoundM)<1e-12);
console.log(JSON.stringify({samples:20000,aboveBase:above,conservativeBoundM:R,maxSampledNormM:maximum,witness,outsideTargetDistanceM:Math.hypot(...saved.unreachableTarget),testsPassed:true,limits:'Kinematics only; no collisions or hardware validation'},null,2));
